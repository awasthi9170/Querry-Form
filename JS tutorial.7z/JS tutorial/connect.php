<?php
  $FirstName = $_POST['FirstName'];
  $LastName = $_POST['LastName'];
  $email = $_POST['email'];
  $password = $_POST['password'];
  $gender = $_POST['gender'];


  //Database Connection
  $conn=new mysqli('localhost','root','','test');
  If($conn->connect_error){
    die('Connection Failed :'.$conn->connect_error);
  }else{
    $stmt=$conn->prepare("insert into registration(FirstName,LastName,email,password,gender)
    values(?,?,?,?,?)");
    $stmt->bind_param("ssssi",$FirstName,$LastName,$gender,$email,$password);
    $stmt->execute();
    echo"registration successfully...";
    $stmt->close();
    $conn->close();
  }